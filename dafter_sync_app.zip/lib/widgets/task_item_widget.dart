import 'package:flutter/material.dart';
import '../models/note.dart';

class TaskItemWidget extends StatefulWidget {
  final TaskItem item;
  final VoidCallback? onDelete;
  final ValueChanged<TaskItem>? onChanged;
  TaskItemWidget({required this.item, this.onDelete, this.onChanged});

  @override
  _TaskItemWidgetState createState() => _TaskItemWidgetState();
}

class _TaskItemWidgetState extends State<TaskItemWidget> {
  late TextEditingController ctrl;

  @override
  void initState() {
    super.initState();
    ctrl = TextEditingController(text: widget.item.text);
  }

  @override
  void dispose() {
    ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Checkbox(
        value: widget.item.done,
        onChanged: (v) {
          setState(() => widget.item.done = v ?? false);
          widget.onChanged?.call(widget.item);
        },
      ),
      title: TextField(
        controller: ctrl,
        decoration: InputDecoration(border: InputBorder.none, hintText: 'اكتب عنصر المهمة'),
        onChanged: (v) {
          widget.item.text = v;
          widget.onChanged?.call(widget.item);
        },
      ),
      trailing: IconButton(
        icon: Icon(Icons.delete_forever),
        onPressed: widget.onDelete,
      ),
    );
  }
}
