import 'package:flutter/material.dart';
import 'storage_service.dart';
import 'firestore_service.dart';
import 'auth_service.dart';
import '../models/note.dart';
import 'dart:async';

class SyncService extends ChangeNotifier {
  final StorageService _local = StorageService();
  final FirestoreService _remote = FirestoreService();

  List<Note> notes = [];
  StreamSubscription? _sub;

  Future<void> loadLocal() async {
    notes = await _local.loadNotes();
    notifyListeners();
  }

  Future<void> saveLocal() async {
    await _local.saveNotes(notes);
  }

  // Start remote sync stream after login
  void startRemoteSync(String uid) {
    _sub?.cancel();
    _sub = _remote.notesStream(uid).listen((remoteNotes) async {
      // Simple merge strategy: replace local with remote
      notes = remoteNotes;
      await saveLocal();
      notifyListeners();
    });
  }

  void stopRemoteSync() {
    _sub?.cancel();
    _sub = null;
  }

  Future<void> pushNoteToRemote(String uid, Note note) async {
    await _remote.setNote(uid, note);
  }

  Future<void> deleteRemote(String uid, String noteId) async {
    await _remote.deleteNote(uid, noteId);
  }
}
