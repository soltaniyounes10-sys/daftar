import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';

class AuthService extends ChangeNotifier {
  final GoogleSignIn _googleSignIn = GoogleSignIn();
  GoogleSignInAccount? user;

  bool get isSignedIn => user != null;

  Future<void> signIn() async {
    try {
      user = await _googleSignIn.signIn();
      notifyListeners();
    } catch (e) {
      print('Google sign in error: $e');
    }
  }

  Future<void> signOut() async {
    await _googleSignIn.signOut();
    user = null;
    notifyListeners();
  }
}
