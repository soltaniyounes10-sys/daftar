import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/note.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Stream<List<Note>> notesStream(String uid) {
    return _db.collection('users').doc(uid).collection('notes').snapshots().map(
        (snap) => snap.docs.map((d) {
              final data = d.data();
              data['id'] = d.id;
              return Note.fromJson(_mapFromFirestore(data));
            }).toList());
  }

  Future<void> setNote(String uid, Note note) async {
    final doc = _db.collection('users').doc(uid).collection('notes').doc(note.id);
    await doc.set(note.toJson());
  }

  Future<void> deleteNote(String uid, String noteId) async {
    await _db.collection('users').doc(uid).collection('notes').doc(noteId).delete();
  }

  static Map<String, dynamic> _mapFromFirestore(Map<String, dynamic> data) {
    // Firestore stores DateTime as Timestamp; ensure strings for constructor
    final out = Map<String, dynamic>.from(data);
    if (out['createdAt'] is Timestamp) out['createdAt'] = (out['createdAt'] as Timestamp).toDate().toIso8601String();
    if (out['updatedAt'] is Timestamp) out['updatedAt'] = (out['updatedAt'] as Timestamp).toDate().toIso8601String();
    return out;
  }
}
