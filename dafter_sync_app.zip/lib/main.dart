import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:provider/provider.dart';
import 'services/auth_service.dart';
import 'screens/home_screen.dart';
import 'services/sync_service.dart';

// NOTE:
// You MUST add your Firebase configuration files:
// - android: android/app/google-services.json
// - iOS: ios/Runner/GoogleService-Info.plist
// And follow Firebase setup steps in the README.

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthService()),
        ChangeNotifierProvider(create: (_) => SyncService()),
      ],
      child: Consumer2<AuthService, SyncService>(
        builder: (context, auth, sync, _) {
          return MaterialApp(
            debugShowCheckedModeBanner: false,
            title: 'دفتر',
            theme: ThemeData(
              fontFamily: 'Cairo',
              brightness: Brightness.light,
              primarySwatch: Colors.teal,
            ),
            home: HomeScreen(),
          );
        },
      ),
    );
  }
}
