import 'dart:convert';

class TaskItem {
  String id;
  String text;
  bool done;

  TaskItem({required this.id, required this.text, this.done = false});

  factory TaskItem.fromJson(Map<String, dynamic> j) => TaskItem(
        id: j['id'],
        text: j['text'],
        done: j['done'] ?? false,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'text': text,
        'done': done,
      };
}

class Note {
  String id;
  String title;
  String content;
  List<TaskItem> tasks;
  String color;
  List<String> tags;
  DateTime createdAt;
  DateTime updatedAt;
  bool locked;

  Note({
    required this.id,
    this.title = '',
    this.content = '',
    List<TaskItem>? tasks,
    this.color = '#FFFFFFFF',
    List<String>? tags,
    DateTime? createdAt,
    DateTime? updatedAt,
    this.locked = false,
  })  : tasks = tasks ?? [],
        tags = tags ?? [],
        createdAt = createdAt ?? DateTime.now(),
        updatedAt = updatedAt ?? DateTime.now();

  factory Note.fromJson(Map<String, dynamic> j) => Note(
        id: j['id'],
        title: j['title'] ?? '',
        content: j['content'] ?? '',
        tasks: (j['tasks'] as List<dynamic>? ?? []).map((e) => TaskItem.fromJson(e)).toList(),
        color: j['color'] ?? '#FFFFFFFF',
        tags: List<String>.from(j['tags'] ?? []),
        createdAt: DateTime.parse(j['createdAt']),
        updatedAt: DateTime.parse(j['updatedAt']),
        locked: j['locked'] ?? false,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'content': content,
        'tasks': tasks.map((t) => t.toJson()).toList(),
        'color': color,
        'tags': tags,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
        'locked': locked,
      };
}
