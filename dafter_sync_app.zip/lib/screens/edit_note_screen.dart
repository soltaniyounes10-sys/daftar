import 'package:flutter/material.dart';
import '../models/note.dart';
import 'package:uuid/uuid.dart';
import '../widgets/task_item_widget.dart';

class EditNoteScreen extends StatefulWidget {
  final Note note;
  EditNoteScreen({required this.note});
  @override
  _EditNoteScreenState createState() => _EditNoteScreenState();
}

class _EditNoteScreenState extends State<EditNoteScreen> {
  late TextEditingController titleController;
  late TextEditingController contentController;

  @override
  void initState() {
    super.initState();
    titleController = TextEditingController(text: widget.note.title);
    contentController = TextEditingController(text: widget.note.content);
  }

  @override
  void dispose() {
    titleController.dispose();
    contentController.dispose();
    super.dispose();
  }

  void _addTask() {
    final id = Uuid().v4();
    final t = TaskItem(id: id, text: '');
    setState(() => widget.note.tasks.add(t));
  }

  void _saveAndClose() {
    widget.note.title = titleController.text;
    widget.note.content = contentController.text;
    widget.note.updatedAt = DateTime.now();
    Navigator.pop(context, widget.note);
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text('تعديل الملاحظة'),
          actions: [
            IconButton(onPressed: _saveAndClose, icon: Icon(Icons.save)),
          ],
        ),
        body: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            children: [
              TextField(
                controller: titleController,
                decoration: InputDecoration(hintText: 'عنوان الملاحظة', border: InputBorder.none),
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              Expanded(
                child: TextField(
                  controller: contentController,
                  decoration: InputDecoration(hintText: 'اكتب ملاحظتك هنا...', border: InputBorder.none),
                  keyboardType: TextInputType.multiline,
                  maxLines: null,
                ),
              ),
              if (widget.note.tasks.isNotEmpty) ...[
                Divider(),
                Text('قائمة مهام', style: TextStyle(fontWeight: FontWeight.bold)),
                SizedBox(height: 8),
                Expanded(
                  child: ListView.builder(
                    itemCount: widget.note.tasks.length,
                    itemBuilder: (ctx, i) {
                      final t = widget.note.tasks[i];
                      return TaskItemWidget(
                        item: t,
                        onChanged: (updated) => setState(() {}),
                        onDelete: () => setState(() => widget.note.tasks.removeAt(i)),
                      );
                    },
                  ),
                ),
              ],
              Row(
                children: [
                  ElevatedButton.icon(onPressed: _addTask, icon: Icon(Icons.playlist_add), label: Text('إضافة عنصر قائمة')),
                  SizedBox(width: 8),
                  Spacer(),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
