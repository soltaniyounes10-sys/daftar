import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/auth_service.dart';
import '../services/sync_service.dart';
import '../models/note.dart';
import 'edit_note_screen.dart';
import 'package:uuid/uuid.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String q = '';
  @override
  void initState() {
    super.initState();
    final sync = Provider.of<SyncService>(context, listen: false);
    sync.loadLocal();
  }

  void _createNote() async {
    final sync = Provider.of<SyncService>(context, listen: false);
    final auth = Provider.of<AuthService>(context, listen: false);
    final id = Uuid().v4();
    final newNote = Note(id: id, title: '', content: '');
    sync.notes.insert(0, newNote);
    await sync.saveLocal();
    final updated = await Navigator.push(context, MaterialPageRoute(builder: (_) => EditNoteScreen(note: newNote)));
    if (updated is Note) {
      newNote.updatedAt = DateTime.now();
      await sync.saveLocal();
      if (auth.isSignedIn) await sync.pushNoteToRemote(auth.user!.id, newNote);
      setState(() {});
    } else {
      if (newNote.title.isEmpty && newNote.content.isEmpty && newNote.tasks.isEmpty) {
        sync.notes.removeWhere((n) => n.id == newNote.id);
        await sync.saveLocal();
      }
    }
  }

  void _delete(Note n) async {
    final sync = Provider.of<SyncService>(context, listen: false);
    final auth = Provider.of<AuthService>(context, listen: false);
    sync.notes.removeWhere((e) => e.id == n.id);
    await sync.saveLocal();
    if (auth.isSignedIn) await sync.deleteRemote(auth.user!.id, n.id);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthService>(context);
    final sync = Provider.of<SyncService>(context);
    final filtered = q.isEmpty ? sync.notes : sync.notes.where((n) => (n.title + n.content + n.tags.join(' ')).contains(q)).toList();

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text('دفتر'),
          actions: [
            if (!auth.isSignedIn)
              TextButton.icon(
                onPressed: () async {
                  await auth.signIn();
                  if (auth.isSignedIn) {
                    sync.startRemoteSync(auth.user!.id);
                  }
                },
                icon: Icon(Icons.login, color: Colors.white),
                label: Text('تسجيل الدخول', style: TextStyle(color: Colors.white)),
              )
            else
              Row(
                children: [
                  Text(auth.user?.displayName ?? '', style: TextStyle(color: Colors.white)),
                  SizedBox(width: 8),
                  TextButton(
                      onPressed: () async {
                        sync.stopRemoteSync();
                        await auth.signOut();
                      },
                      child: Text('تسجيل الخروج', style: TextStyle(color: Colors.white))),
                ],
              )
          ],
          bottom: PreferredSize(
            preferredSize: Size.fromHeight(56),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 8.0),
              child: TextField(
                decoration: InputDecoration(
                  hintText: 'ابحث عن ملاحظة أو وسم...',
                  prefixIcon: Icon(Icons.search),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                ),
                onChanged: (v) => setState(() => q = v),
              ),
            ),
          ),
        ),
        body: filtered.isEmpty
            ? Center(child: Text('لا توجد ملاحظات بعد. اضغط + لإضافة ملاحظة جديدة.'))
            : ListView.builder(
                itemCount: filtered.length,
                itemBuilder: (ctx, i) {
                  final note = filtered[i];
                  return Dismissible(
                    key: Key(note.id),
                    direction: DismissDirection.startToEnd,
                    background: Container(color: Colors.red, alignment: Alignment.centerRight, padding: EdgeInsets.only(right: 20), child: Icon(Icons.delete, color: Colors.white)),
                    onDismissed: (_) => _delete(note),
                    child: ListTile(
                      title: Text(note.title.isEmpty ? (note.content.split('\n').first.isEmpty ? 'ملاحظة جديدة' : note.content.split('\n').first) : note.title),
                      subtitle: note.tasks.isNotEmpty ? Text('${note.tasks.where((t) => !t.done).length} عناصر متبقية') : Text(note.content, maxLines: 2, overflow: TextOverflow.ellipsis),
                      onTap: () async {
                        final updated = await Navigator.push(context, MaterialPageRoute(builder: (_) => EditNoteScreen(note: note)));
                        if (updated is Note) {
                          note.updatedAt = DateTime.now();
                          await sync.saveLocal();
                          if (auth.isSignedIn) await sync.pushNoteToRemote(auth.user!.id, note);
                          setState(() {});
                        }
                      },
                    ),
                  );
                },
              ),
        floatingActionButton: FloatingActionButton(
          onPressed: _createNote,
          child: Icon(Icons.add),
        ),
      ),
    );
  }
}
