دفتر - تطبيق Flutter مع مزامنة Firebase (Firestore) وGoogle Sign-In
===============================================================

خطوات مهمة قبل التشغيل:
1. إنشاء مشروع في Firebase Console (https://console.firebase.google.com).
2. إضافة تطبيق Android و/أو iOS داخل المشروع.
3. تنزيل ملف google-services.json (Android) ووضعه في android/app/.
   أو تنزيل GoogleService-Info.plist ووضعه في ios/Runner/.
4. تفعيل Firestore من لوحة Firebase.
5. تحديث ملفات gradle إذا لزم الأمر (راجع وثائق Firebase-Flutter).

ملاحظات حول الشيفرة:
- المزامنة بسيطة: عند تسجيل الدخول يبدأ Stream من مجموعة المستخدم notes ويتم استبدال البيانات المحلية بالبعيدة.
- عند إجراء تغييرات محلية بعد تسجيل الدخول، الشيفرة تدفع (push) التعديلات بعناصر منفردة إلى Firestore.
- لاتنسى تشغيل: flutter pub get

تشغيل محلي (مع Firebase متصل):
- افتح المشروع في Android Studio أو VS Code.
- شغّل الأمر: flutter pub get
- ثم: flutter run
